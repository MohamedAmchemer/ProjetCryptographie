package com.Amchemer.cryptography;

public class CesarCipher {

        public static String encryptC(String texto , int chave) {
            StringBuilder textoCifrado = new StringBuilder();
            int tamanhoTexto = texto.length();

            for (int c = 0; c < tamanhoTexto; c++) {
                int letraCifradaASCII = (texto.charAt(c)) + (chave);

                while (letraCifradaASCII > 126) {
                    letraCifradaASCII -= 94;
                }

                textoCifrado.append((char) letraCifradaASCII);
            }

            return textoCifrado.toString();
        }

        public static String decryptC(String textChiffre , int chave) {
            StringBuilder texto = new StringBuilder();
            int tamanhoTexto = textChiffre.length();

            for (int c = 0; c < tamanhoTexto; c++) {
                int letraDecifradaASCII = (textChiffre.charAt(c)) - (chave);

                while (letraDecifradaASCII < 32) {
                    letraDecifradaASCII += 94;
                }

                texto.append((char) letraDecifradaASCII);
            }

            return texto.toString();
        }
    }