package com.Amchemer.cryptography;
import java.util.Scanner;

public class TranspositionsRecCipher {

    private static Scanner in;


    public static String encryption(String msg , String keyword){

        // assigning numbers to keywords
        int[] kywrdNumList = keywordNumAssign(keyword);

        // printing keyword
        for (int i = 0, j = 1; i < keyword.length(); i++, j++) {
            System.out.print(keyword.substring(i, j) + " ");
        }
        System.out.println();

        for (int i: kywrdNumList){
            System.out.print(i + " ");

        }
        // in case characters don't fit the entire grid perfectly.
        int extraLetters = msg.length() % keyword.length();
        //System.out.println(extraLetters);
        int dummyCharacters = keyword.length() - extraLetters;
//        System.out.println(dummyCharacters);

        int numOfRows = msg.length() / keyword.length();

        // Converting message into a grid
        char[][] arr = new char[numOfRows][keyword.length()];

        int z = 0;
        for (int i = 0; i < numOfRows; i++) {
            for (int j = 0; j < keyword.length(); j++) {
                arr[i][j] = msg.charAt(z);
                z++;
            }

        }

        for (int i = 0; i < numOfRows; i++) {
            for (int j = 0; j < keyword.length(); j++) {
                System.out.print(arr[i][j] + " ");
            } // inner for loop
            System.out.println();
        } // for loop

        // cipher text generation
        String cipherText = new String();


        // getting locations of numbers
        String numLoc = getNumberLocation(keyword, kywrdNumList);


        for (int i = 0, k = 0; i < numOfRows; i++, k++) {
            int d;
            if (k == keyword.length()){
                break;
            } else {
                d = Character.getNumericValue(numLoc.charAt(k));
            }
        }

        return cipherText;

    } // encryption method

    public static String decryption(String msg , String keyword){



        int numOfRows = msg.length() / keyword.length();

        // array with dummy values
        char[][] arr = new char[numOfRows][keyword.length()];

        // assigning numbers to keywords
        int[] kywrdNumList = keywordNumAssign(keyword);

        String numLoc = getNumberLocation(keyword, kywrdNumList);

        for (int i = 0, k = 0; i < msg.length(); i++, k++) {
            int d = 0;
            if (k == keyword.length()){
                k = 0;
            } else {
                d = Character.getNumericValue(numLoc.charAt(k));
            }

            for (int j = 0; j < numOfRows; j++, i++) {
                arr[j][d] = msg.charAt(i);
            } // for loop
            --i;
        }

        String plainText = new String();

        return plainText;

    } // decryption function

    private static String getNumberLocation(String keyword, int[] kywrdNumList) {
        String numLoc = "";
        for (int i = 1; i < keyword.length() + 1; i++) {
            for (int j = 0; j < keyword.length(); j++) {
                if (kywrdNumList[j] == i){
                    numLoc += j;
                }
            }
        }
        return numLoc;
    } // getting number location function

    private static int[] keywordNumAssign(String keyword) {
        String alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        int[] kywrdNumList = new int[keyword.length()];

        int init = 0;
        for (int i = 0; i < alpha.length(); i ++){
            for (int j = 0; j < keyword.length(); j++) {
                if (alpha.charAt(i) == keyword.charAt(j)){
                    init++;
                    kywrdNumList[j] = init;
                }
            } // inner for
        } // for
        return kywrdNumList;
    } // keyword number assignment function

} // class
